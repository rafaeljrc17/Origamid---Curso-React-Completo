import React from 'react';

const App = () => {
  return <a href="https://www.origamid.com">Origamid</a>;
};

export default App;
